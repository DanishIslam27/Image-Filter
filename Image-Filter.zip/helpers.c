#include "helpers.h"
#include <math.h>
#include <stdio.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // Setting float values
            float red_value = image[i][j].rgbtRed;
            float green_value = image[i][j].rgbtGreen;
            float blue_value = image[i][j].rgbtBlue;

            // Average grey scale value
            float average_value = (red_value + green_value + blue_value) / 3;

            // Assigning grey value to each colour
            image[i][j].rgbtRed = round(average_value);
            image[i][j].rgbtGreen = round(average_value);
            image[i][j].rgbtBlue = round(average_value);
        }
    }
    return;
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // Setting float values
            float red_value = image[i][j].rgbtRed;
            float green_value = image[i][j].rgbtGreen;
            float blue_value = image[i][j].rgbtBlue;

            // Calculating sepia values
            float sepia_red = (0.393 * red_value) + (0.769 * green_value) + (0.189 * blue_value);
            float sepia_green = (0.349 * red_value) + (0.686 * green_value) + (0.168 * blue_value);
            float sepia_blue = (0.272 * red_value) + (0.534 * green_value) + (0.131 * blue_value);

            // Assigning red value
            if (round(sepia_red) >= 0 && round(sepia_red) <= 255)
            {
                image[i][j].rgbtRed = round(sepia_red);
            }
            else if (round(sepia_red) > 255)
            {
                image[i][j].rgbtRed = 255;
            }

            // Assigning green value
            if (round(sepia_green) >= 0 && round(sepia_green) <= 255)
            {
                image[i][j].rgbtGreen = round(sepia_green);
            }
            else if (round(sepia_green) > 255)
            {
                image[i][j].rgbtGreen = 255;
            }

            // Assigning blue value
            if (round(sepia_blue) >= 0 && round(sepia_blue) <= 255)
            {
                image[i][j].rgbtBlue = round(sepia_blue);
            }
            else if (round(sepia_blue) > 255)
            {
                image[i][j].rgbtBlue = 255;
            }
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width/2; j++)
        {
            // Switching red variables
            int tempRedValue = image[i][j].rgbtRed;
            image[i][j].rgbtRed = image[i][width - j - 1].rgbtRed;
            image[i][width - j - 1].rgbtRed = tempRedValue;

            // Switching green variables
            int tempGreenValue = image[i][j].rgbtGreen;
            image[i][j].rgbtGreen = image[i][width - j - 1].rgbtGreen;
            image[i][width - j - 1].rgbtGreen = tempGreenValue;

            // Switching blue variables
            int tempBlueValue = image[i][j].rgbtBlue;
            image[i][j].rgbtBlue = image[i][width - j - 1].rgbtBlue;
            image[i][width - j - 1].rgbtBlue = tempBlueValue;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // Basics
    RGBTRIPLE temp[height][width];

    // First double loop for finding the pixel
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            // Setting base values
            float counter = 0;
            int totalredvalue = 0;
            int totalgreenvalue = 0;
            int totalbluevalue = 0;

            // Second double loop for the 3x3 grind
            for (int gr = -1; gr < 2; gr++)
            {
                for (int gc = -1; gc < 2; gc++)
                {
                    // If statement to check if pixel exists, if not it breaks
                    if (gr+i < 0 || gr+i > height-1 || gc+j < 0 || gc+j > width-1)
                    {
                        continue;
                    }

                    // If pixel exists it adds it to the total red value, also adds to counter
                    totalredvalue = image[gr+i][gc+j].rgbtRed;
                    totalgreenvalue = image[gr+i][gc+j].rgbtGreen;
                    totalbluevalue = image[gr+i][gc+j].rgbtBlue;
                    counter = counter+1;
                }
            }

            float redfloat = totalredvalue;
            float greenfloat = totalgreenvalue;
            float bluefloat = totalbluevalue;

            // Calculating average values for each colour
            float averageredvalue = (redfloat) / counter;
            float averagebluevalue = (bluefloat) / counter;
            float averagegreenvalue = (greenfloat) / counter;

            // Assigning colour values to pixel
            temp[i][j].rgbtRed = round(averageredvalue);
            temp[i][j].rgbtGreen = round(averagegreenvalue);
            temp[i][j].rgbtBlue = round(averagebluevalue);
        }
    }

    // Another double for-loop to assign values
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtRed = temp[i][j].rgbtRed;
            image[i][j].rgbtGreen = temp[i][j].rgbtGreen;
            image[i][j].rgbtBlue = temp[i][j].rgbtBlue;
        }
    }
    return;
}
